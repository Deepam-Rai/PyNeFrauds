from .Neo4jHandler import Neo4jHandler
neo4jHandler = Neo4jHandler() #handles interaction with Neo4j database
